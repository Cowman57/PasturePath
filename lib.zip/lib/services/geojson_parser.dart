import 'dart:convert';
import 'dart:typed_data';
import 'package:latlong2/latlong.dart';

import '../models/paddock.dart';

class ParsedResult {
  final List<Paddock> paddocks;
  final String? error;
  ParsedResult({required this.paddocks, this.error});
}

class GeoJsonParser {
  static ParsedResult parseBytes(Uint8List bytes) {
    try {
      final txt = utf8.decode(bytes);
      final root = json.decode(txt);

      if (root is! Map || root['type'] != 'FeatureCollection') {
        return ParsedResult(paddocks: const [], error: 'Not a FeatureCollection');
      }

      final feats = (root['features'] as List?) ?? const [];
      final paddocks = <Paddock>[];

      for (final f in feats) {
        if (f is! Map) continue;
        final props = (f['properties'] as Map?) ?? const {};
        final geom = (f['geometry'] as Map?) ?? const {};
        final gtype = (geom['type'] as String?) ?? '';

        final name = '${props['name'] ?? props['pdk'] ?? props['PDK'] ?? ''}'.trim();
        final areaHa = _numToDouble(props['areaHa'] ?? props['area'] ?? 0);

        if (gtype == 'Polygon') {
          final rings = _readPolygon(geom['coordinates']);
          if (rings.isEmpty) continue;
          final outer = rings.first;
          final holes = rings.length > 1 ? rings.sublist(1) : <List<LatLng>>[];
          final label = _pointOnSurface(outer, holes);
          paddocks.add(Paddock(
            name: name.isEmpty ? (paddocks.length + 1).toString() : name,
            outer: outer,
            holes: holes,
            areaHa: areaHa,
            labelPoint: label,
          ));
        } else if (gtype == 'MultiPolygon') {
          final polys = (geom['coordinates'] as List?) ?? const [];
          for (final poly in polys) {
            final rings = _readPolygon(poly);
            if (rings.isEmpty) continue;
            final outer = rings.first;
            final holes = rings.length > 1 ? rings.sublist(1) : <List<LatLng>>[];
            final label = _pointOnSurface(outer, holes);
            paddocks.add(Paddock(
              name: name.isEmpty ? (paddocks.length + 1).toString() : name,
              outer: outer,
              holes: holes,
              areaHa: areaHa,
              labelPoint: label,
            ));
          }
        }
      }

      return ParsedResult(paddocks: paddocks);
    } catch (e) {
      return ParsedResult(paddocks: const [], error: '$e');
    }
  }

  static List<List<LatLng>> _readPolygon(dynamic coordsAny) {
    final out = <List<LatLng>>[];
    final rings = (coordsAny as List?) ?? const [];
    for (final r in rings) {
      final ring = <LatLng>[];
      final pts = (r as List?) ?? const [];
      for (final p in pts) {
        if (p is List && p.length >= 2) {
          final lon = _numToDouble(p[0]);
          final lat = _numToDouble(p[1]);
          ring.add(LatLng(lat, lon));
        }
      }
      if (ring.length >= 3) out.add(ring);
    }
    return out;
  }

  static double _numToDouble(Object? v) {
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v) ?? 0.0;
    return 0.0;
  }

  /// Point-on-surface: start with centroid; if it falls in a hole/outside,
  /// nudge toward the biggest safe direction.
  static LatLng _pointOnSurface(List<LatLng> outer, List<List<LatLng>> holes) {
    // Simple polygon centroid
    double a = 0, cx = 0, cy = 0;
    for (int i = 0, j = outer.length - 1; i < outer.length; j = i++) {
      final xi = outer[i].longitude, yi = outer[i].latitude;
      final xj = outer[j].longitude, yj = outer[j].latitude;
      final cross = xj * yi - xi * yj;
      a += cross;
      cx += (xj + xi) * cross;
      cy += (yj + yi) * cross;
    }
    if (a == 0) {
      // fallback average
      final avgLat = outer.map((e) => e.latitude).reduce((v, e) => v + e) / outer.length;
      final avgLon = outer.map((e) => e.longitude).reduce((v, e) => v + e) / outer.length;
      return LatLng(avgLat, avgLon);
    }
    a *= 0.5;
    final C = LatLng(cy / (6 * a), cx / (6 * a));

    bool inside = _inRing(C, outer) && holes.every((h) => !_inRing(C, h));
    if (inside) return C;

    // Nudge step
    const step = 0.0002; // about ~20m depending on lat
    final dirs = <LatLng>[
      LatLng(C.latitude + step, C.longitude),
      LatLng(C.latitude - step, C.longitude),
      LatLng(C.latitude, C.longitude + step),
      LatLng(C.latitude, C.longitude - step),
    ];
    for (final d in dirs) {
      if (_inRing(d, outer) && holes.every((h) => !_inRing(d, h))) return d;
    }
    return C; // last resort
  }

  static bool _inRing(LatLng p, List<LatLng> ring) {
    bool inside = false;
    for (int i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      final xi = ring[i].longitude, yi = ring[i].latitude;
      final xj = ring[j].longitude, yj = ring[j].latitude;
      final intersect = ((yi > p.latitude) != (yj > p.latitude)) &&
          (p.longitude < (xj - xi) * (p.latitude - yi) / ((yj - yi) + 1e-12) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }
}
